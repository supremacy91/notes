<?php

require_once 'PHPUnit/Framework.php';

class NewsTest extends PHPUnit_Framework_TestCase
{

    protected $_newsModel;

    public function setUp()
    {
        echo 'Starting test for ', $this->getName(), '() method';
        Mage::app('default');
        $this->_newsModel = Mage::getModel('news/news');
    }

    protected function tearDown()
    {
        
    }

    public function testGetAllNews()
    {
        $newses = $this->_newsModel->getCollection();
        $this->assertEquals(2, sizeof($newses));
    }

}