<?php

ini_set('include_path', ini_get('include_path') . PATH_SEPARATOR . dirname(__FILE__) . '/../app' . PATH_SEPARATOR . dirname(__FILE__));

//code coverage generation requires lots of memory
ini_set('memory_limit', '512M');

//autoloading will work as we set the inlcude path earlier
require_once 'Mage.php';

//creating the Magento application instance
Mage::app('default');

//so we don't get "Headers already sent message" in case of error, can also var_dump now...
session_start();