<?php

/**
 * PACKT News Data Helper
 *
 * @category   PACKT
 * @package    PACKT_News
 * @author     Nurul Ferdous <ferdous@dynamicguy.com>
 */
class PACKT_News_Helper_Data extends Mage_Core_Helper_Abstract
{

}